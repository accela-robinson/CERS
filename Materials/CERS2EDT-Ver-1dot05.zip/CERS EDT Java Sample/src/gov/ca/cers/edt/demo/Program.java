package gov.ca.cers.edt.demo;

import java.io.Console;
import java.io.UnsupportedEncodingException;
import java.nio.charset.Charset;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

import org.apache.commons.codec.binary.Base64;
import org.apache.commons.codec.binary.Hex;

public class Program {

	/**
	 * @param args
	 */
	public static void main(String[] args) 
	{
		//define variables
		int regulatorCode = 1900; //LA County for example.
		String username = "username";
		String password = "password";
		
		//get encrypted password...
		String encryptedPassword = generatePassword(password);
		
		//build the authorization header VALUE
		String authorizationHeader = "user " + username + ":" + encryptedPassword;
		
		//Note: The actual "value" of the Authorization HTTP Header should look like the following
		//"user username:sha1hashedpassword"
		
		System.out.println("Authorization Header: " + authorizationHeader);
		
		//the URL to the staging version of the Regulator Authentication Test (RAT) service.
		String ratServiceUrl = "https://cersservices.calepa.ca.gov/Staging/Regulator/Authenticate?regulatorCode=" + regulatorCode;
		System.out.println("Service Url: " + ratServiceUrl);
		
		//init the RestClient class.
		RestClient client = new RestClient(authorizationHeader);
		
		//get the result 
		RestClientResult result = client.get(ratServiceUrl);
		
		//print the results
		System.out.println("Status Code: " + result.getStatusLine().getStatusCode());
		System.out.println("Status Description: " + result.getStatusLine().getReasonPhrase());
		System.out.println("Data Returned: ");
		System.out.println(result.getStringData());
		
	}
	
	public static String generatePassword(String password) 
	{
		String encryptedPassword = "";
		
		MessageDigest SHA1 = null;
		
		try 
		{
			SHA1 = MessageDigest.getInstance("SHA1");
		}
		catch (NoSuchAlgorithmException nae) 
		{
			throw new RuntimeException(nae);
		}
		
		if (SHA1 != null) {
			
			SHA1.update(password.getBytes());
			byte[] encryptedRaw = SHA1.digest();
			byte[] encoded = Base64.encodeBase64(encryptedRaw);
			
			try 
			{
				encryptedPassword = new String(encoded, "UTF-8");
			} 
			catch (UnsupportedEncodingException uee) 
			{
			    throw new RuntimeException(uee);
			}
		}

        return encryptedPassword;
    }
}
