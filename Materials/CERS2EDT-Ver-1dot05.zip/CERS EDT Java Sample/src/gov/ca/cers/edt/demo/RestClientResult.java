package gov.ca.cers.edt.demo;

import org.apache.http.StatusLine;

public class RestClientResult {

	private StatusLine mStatusLine;
	private String mStringData;
	
	public StatusLine getStatusLine() {
		return mStatusLine;
	}
	
	public void setStatusLine(StatusLine statusLine) {
		mStatusLine = statusLine;
	}

	public String getStringData() {
		return mStringData;
	}
	
	public void setStringData(String stringData) {
		mStringData = stringData;
	}
	
}
