package gov.ca.cers.edt.demo;

import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.StatusLine;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.params.BasicHttpParams;
import org.apache.http.params.HttpConnectionParams;
import org.apache.http.params.HttpParams;
import org.apache.http.params.HttpProtocolParams;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.text.MessageFormat;

public class RestClient
{
	private String mAuthorizationHeader;
	
	public RestClient(String authorizationHeader) {
		mAuthorizationHeader = authorizationHeader;
	}
	
	// RestClient options, all in seconds
	private static final int 	MAX_ATTEMPTS		= 3; 
	private static final int 	CONNECTION_TIMEOUT 	= 10;
	private static final int	READ_TIMEOUT		= 10;
	private static final int	RETRY_INTERVAL		= 3;
	
	private final String		ENCODING			= "UTF-8"; 
	
	private HttpParams			httpParams			= new BasicHttpParams();
	private DefaultHttpClient	httpclient			= new DefaultHttpClient(httpParams);

	public RestClientResult get(String url) {
		
		RestClientResult result = new RestClientResult();
		
		HttpConnectionParams.setConnectionTimeout(httpParams, CONNECTION_TIMEOUT * 1000);
		HttpConnectionParams.setSoTimeout(httpParams, READ_TIMEOUT * 1000);
		httpParams.setBooleanParameter(HttpProtocolParams.USE_EXPECT_CONTINUE, false);
		
		HttpGet httpget = new HttpGet(url);
		httpget.setHeader("Authorization", mAuthorizationHeader);
		
		HttpResponse response = null;
		HttpEntity entity = null;
		InputStream inputStream = null;
		
		for (int i=0; i < MAX_ATTEMPTS; i++)
		{
			try
			{
				response = httpclient.execute(httpget);			
				entity = response.getEntity();
				
				result.setStatusLine(response.getStatusLine());
				
				inputStream = entity.getContent();
				BufferedReader reader = new BufferedReader(new InputStreamReader(inputStream, ENCODING), 8);
				StringBuilder sb = new StringBuilder();
		
				String line = null;
				while ((line = reader.readLine()) != null)
				{
					sb.append(line + "\n");
				}
				result.setStringData(sb.toString());
			}
			catch (Exception e)
			{
				// Pause between attempts
				try { Thread.sleep(RETRY_INTERVAL * 1000); } catch (InterruptedException ie) {}
			}
			finally
			{
				try 
				{
					if (inputStream != null) {
						inputStream.close();
					}
				} 
				catch(Exception squish)
				{
					//absorb error
				}
			}
			
			if (result != null) {
				break;
			}
		}

		return result;
	}
	
	
}

