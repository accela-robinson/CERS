This Schemas/Client package was releaseed on May 16, 2013. 

If you are NOT familiar with the CERS EDT XML Schemas, please review the CERS EDT web site at http://cers.calepa.ca.gov/EDT/, and then read the most current EDT Services Manual shown on that page. 

The XML Schemas are in the /XSD/ directory.

A complete sample Windows Client solution is available in the /CERS.EDT.Windows.Client/ directory. This is kept up-to-date by CERS Technical Services staff.

A sample Java client in the \CERS EDT Java Sample\ directory was current as of March 2013 but is NOT maintained by CERS Technical Services staff.


Details about reporting fields are available in the CERS Data Registry located at https://cersapps.calepa.ca.gov/DataRegistry/.

 