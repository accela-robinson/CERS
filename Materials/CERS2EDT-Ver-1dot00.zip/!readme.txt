If you are NOT familiar with the CERS EDT XML Schemas, please review the CERS EDT web site at http://cers.calepa.ca.gov/EDT/, and then read the most current EDT Services Manual at http://cers.calepa.ca.gov/TempDocs/EDT/EDTManual-dot91.pdf. 

If you have read the December 2011 version of the CERS EDT Services Manual (0.90), only minor modifications are included in the current/interim version of this manual (0.91), so you may wish to focus on the SchemaChangeLogSummary.pdf document.

The XML Schemas are in the /XSD/ directory.

Details about reporting fields are available in the CERS Data Registry located at https://cersapps.calepa.ca.gov/DataRegistry/.

 